object Database {
    val listOfRequest : MutableList<Request> = mutableListOf<Request>()
    val listOfEmployees : MutableList<Employee> = mutableListOf()
}
enum class Status {
    PENDING,
    APPROVED,
    REJECTED
}
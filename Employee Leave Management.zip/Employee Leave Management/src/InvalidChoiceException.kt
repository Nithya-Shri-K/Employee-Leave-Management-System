class InvalidChoiceException(errorMessage : String) : RuntimeException(errorMessage) {

}
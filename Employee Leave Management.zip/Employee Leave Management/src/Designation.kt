enum class Designation {
    HR,
    WEBDEVELOPER,
    APPDEVELOPER,
    QA
}
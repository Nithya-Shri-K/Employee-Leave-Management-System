enum class TypeOfLeave {
    CASUALLEAVE,
    SICKLEAVE
}